/**
 * @file mce-hal.c
 * Hardware Abstraction Layer for MCE
 * <p>
 * Copyright � 2009-2010 Nokia Corporation and/or its subsidiary(-ies).
 * <p>
 * @author David Weinehall <david.weinehall@nokia.com>
 *
 * mce is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License
 * version 2.1 as published by the Free Software Foundation.
 *
 * mce is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with mce.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <glib.h>

#include <string.h>			/* strstr() */
#include <stdlib.h>			/* free() */

#include "mce-hal.h"

#include "mce-log.h"			/* mce_log(), LL_* */
#include "mce-io.h"

/**
 * The product ID of the device
 */
static product_id_t product_id = PRODUCT_UNSET;

/**
 * Get product ID
 *
 * @return The product ID
 */
product_id_t get_product_id(void)
{
	gchar *mem = NULL;

	if (product_id != PRODUCT_UNSET)
		goto EXIT;

	if (!mce_read_string_from_file("/proc/component_version",&mem))
		goto EXIT;

	if (strstr(mem, PRODUCT_SU18_STR)) {
		product_id = PRODUCT_SU18;
	} else if (strstr(mem, PRODUCT_RX34_STR)) {
		product_id = PRODUCT_RX34;
	} else if (strstr(mem, PRODUCT_RX44_STR)) {
		product_id = PRODUCT_RX44;
	} else if (strstr(mem, PRODUCT_RX48_STR)) {
		product_id = PRODUCT_RX48;
	} else if (strstr(mem, PRODUCT_RX51_STR)) {
		product_id = PRODUCT_RX51;
	} else {
		product_id = PRODUCT_UNKNOWN;
	}

	g_free(mem);

EXIT:
	return product_id;
}

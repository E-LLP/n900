/**
 * @file vibrator.c
 * Vibrator interface module for the Mode Control Entity
 * <p>
 * Copyright � 2005-2009 Nokia Corporation and/or its subsidiary(-ies).
 * Copyright � 2011 Jonathan Wilson
 * <p>
 *
 * mce is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License
 * version 2.1 as published by the Free Software Foundation.
 *
 * mce is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with mce.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib.h>
#include <gmodule.h>
#include <string.h>
#include <stdlib.h>
#include <glib/gstdio.h>
#include "mce.h"
#include "mce-log.h"
#include "mce-dbus.h"
#include "datapipe.h"
#include "mce-io.h"
#include "mce-conf.h"

typedef struct
{
	gchar *name;
	guint priority;
	guint policy;
	gint timeout;
	guint repeat;
	guint accelerate_period;
	guint on_period;
	guint break_period;
	guint off_period;
	guint speed;
	gboolean active;
} vibrator_pattern_struct;

gint vibrator_type = -1;
const gchar *vibrator_patterns_name;
guint vibrator_timeout_cb_id;
guint vibrator_on_off_timeout_cb_id;
gboolean vibrator_enabled;
guint vibrator_state;
vibrator_pattern_struct *current;
guint trigger_count;
GQueue *vibrator_patterns;

gint vibrator_pattern_sort_func(gconstpointer a, gconstpointer b, gpointer user_data);
gint get_vibrator_type(void);
void cancel_vibrator_timeout(void);
void cancel_vibrator_on_off_timeout(void);
void stop_vibrator(void);
void vibrator_disable(void);
void g_module_unload(GModule *module);
void trigger_vibrator(unsigned int accelerateperiod, unsigned int onperiod, unsigned int breakperiod, unsigned int speed);
void update_vibrator_state(void);
void start_vibrator(void);
void call_state_pipe_handler(gconstpointer data);
void display_state_pipe_handler(gconstpointer data);
void system_state_pipe_handler(gconstpointer data);
void vibrator_enable(void);
gboolean vibrator_timeout_cb(gpointer data);
gboolean vibrator_on_off_timeout_cb(gpointer data);
const gchar *g_module_check_init(GModule *module);
gboolean req_vibrator_disable_cb(DBusMessage *const msg);
gboolean req_vibrator_enable_cb(DBusMessage *const msg);
void deactivate_vibrator_pattern(const gchar *pattern);
void vibrator_pattern_deactivate_pipe_handler(gconstpointer data);
gboolean req_stop_manual_vibration_cb(DBusMessage *const msg);
void activate_vibrator_pattern(const gchar *pattern);
void vibrator_pattern_activate_pipe_handler(gconstpointer data);
gint vibrator_search_cb(gconstpointer a, gconstpointer b);
gboolean req_start_manual_vibration_cb(DBusMessage *const msg);
gboolean req_vibrator_pattern_deactivate_cb(DBusMessage *const msg);
gboolean req_vibrator_pattern_activate_cb(DBusMessage *const msg);

#define MODULE_NAME		"vibrator"

/** Functionality provided by this module */
static const gchar *const provides[] = { MODULE_NAME, NULL };

/** Module information */
G_MODULE_EXPORT module_info_struct module_info = {
	/** Name of the module */
	.name = MODULE_NAME,
	/** Module provides */
	.provides = provides,
	/** Module priority */
	.priority = 100
};

gint vibrator_pattern_sort_func(gconstpointer a, gconstpointer b, gpointer user_data)
{
	(void)user_data;
	return ((vibrator_pattern_struct *)a)->priority - ((vibrator_pattern_struct *)b)->priority;
}

gint get_vibrator_type(void)
{
	if ( vibrator_type == -1 )
	{
		if ( g_access("/sys/class/i2c-adapter/i2c-1/1-0048/twl4030_vibra/pulse", 2) )
		{
			vibrator_type = 0;
		}
		else
		{
			vibrator_type = 1;
			vibrator_patterns_name = "VibraPatternRX51";
		}
		mce_log(5, "Vibrator-type: %d", vibrator_type);
	}
	return vibrator_type;
}

void cancel_vibrator_timeout(void)
{
	if ( vibrator_timeout_cb_id )
	{
		g_source_remove(vibrator_timeout_cb_id);
		vibrator_timeout_cb_id = 0;
	}
}

void cancel_vibrator_on_off_timeout(void)
{
	if ( vibrator_on_off_timeout_cb_id )
	{
		g_source_remove(vibrator_on_off_timeout_cb_id);
		vibrator_on_off_timeout_cb_id = 0;
	}
}

void stop_vibrator(void)
{
	cancel_vibrator_on_off_timeout();
	if ( get_vibrator_type() == 1 )
		mce_write_string_to_file("/sys/class/i2c-adapter/i2c-1/1-0048/twl4030_vibra/pulse", "0 0");
}

void vibrator_disable(void)
{
	vibrator_enabled = 0;
	stop_vibrator();
	cancel_vibrator_timeout();
}

void g_module_unload(GModule *module)
{
	(void)module;
	vibrator_pattern_struct *pattern;
	vibrator_disable();
	remove_output_trigger_from_datapipe(&call_state_pipe, call_state_pipe_handler);
	remove_output_trigger_from_datapipe(&display_state_pipe, display_state_pipe_handler);
	remove_output_trigger_from_datapipe(&system_state_pipe, system_state_pipe_handler);
	if ( vibrator_patterns )
	{
		while ((pattern = g_queue_pop_head(vibrator_patterns)) != NULL)
		{
			g_free(pattern->name);
			g_slice_free1(0x2Cu, pattern);
		}
		g_queue_free(vibrator_patterns);
	}
	cancel_vibrator_on_off_timeout();
	cancel_vibrator_timeout();
}

void trigger_vibrator(unsigned int accelerateperiod, unsigned int onperiod, unsigned int breakperiod, unsigned int speed)
{
	if ( get_vibrator_type() == 1 )
	{
		int tmp1 = accelerateperiod >= 1 ? 4 : 0;
		if (onperiod)
			tmp1 += 2;
		int tmp2 = tmp1 - ((breakperiod < 1) - 1);
		char *str;
		switch ( tmp2 )
		{
			case 7:
				str = g_strdup_printf("%d %d %d %d %d %d", 255, accelerateperiod, speed, onperiod, -255, breakperiod);
				break;
			case 6:
				str = g_strdup_printf("%d %d %d %d", 255, accelerateperiod, speed, onperiod);
				break;
			case 5:
				str = g_strdup_printf("%d %d %d %d", 255, accelerateperiod, -255, breakperiod);
				break;
			case 4:
				str = g_strdup_printf("%d %d", 255, accelerateperiod);
				break;
			case 3:
				str = g_strdup_printf("%d %d %d %d", speed, onperiod, -255, breakperiod);
				break;
			case 2:
				str = g_strdup_printf("%d %d", speed, onperiod);
				break;
			case 1:
				str = g_strdup_printf("%d %d", -255, breakperiod);
				break;
			case 0:
				str = g_strdup_printf("%d 0", speed);
				break;
			default:
				return;
		}
		if ( str )
		{
			mce_write_string_to_file("/sys/class/i2c-adapter/i2c-1/1-0048/twl4030_vibra/pulse", str);
			g_free(str);
		}
	}
}

void update_vibrator_state(void)
{
	if ( vibrator_state )
	{
		if ( vibrator_state == 1 )
		{
			vibrator_on_off_timeout_cb_id = g_timeout_add(current->off_period, vibrator_on_off_timeout_cb, 0);
			vibrator_state = 2;
		}
		else
		{
			if ( trigger_count + 1 == current->repeat )
			{
				current->active = 0;
				cancel_vibrator_timeout();
				vibrator_state = 0;
				start_vibrator();
			}
			else
			{
				vibrator_state = 1;
				trigger_vibrator(current->accelerate_period,current->on_period,current->break_period,current->speed);
				vibrator_on_off_timeout_cb_id = g_timeout_add(current->break_period + current->accelerate_period + current->on_period,vibrator_on_off_timeout_cb,0);
				trigger_count -= (current->repeat < 1u) - 1;
			}
		}
	}
	else
	{
		trigger_count = 0;
		vibrator_state = 1;
		trigger_vibrator(current->accelerate_period,current->on_period,current->break_period,current->speed);
		if (current->break_period + current->accelerate_period + current->on_period)
		{
			vibrator_on_off_timeout_cb_id = g_timeout_add(current->break_period + current->accelerate_period + current->on_period,vibrator_on_off_timeout_cb, 0);
		}
	}
}

void start_vibrator(void)
{
	display_state_t display_state = datapipe_get_gint(display_state_pipe);
	system_state_t system_state = datapipe_get_gint(system_state_pipe);
	call_state_t call_state = datapipe_get_gint(call_state_pipe);
	if ( g_queue_is_empty(vibrator_patterns) == 1 )
	{
		stop_vibrator();
		cancel_vibrator_timeout();
	}
	else
	{
		int count = 0;
		vibrator_pattern_struct *pattern;
		while (TRUE)
		{
			do
			{
				pattern = (vibrator_pattern_struct *)g_queue_peek_nth(vibrator_patterns, count);
				if (!pattern)
				{
					current = 0;
					stop_vibrator();
					cancel_vibrator_timeout();
					return;
				}
				mce_log(5, "pattern: %s, active: %d", pattern->name, pattern->active);
			} while ( !pattern->active );
			if ((pattern->policy == 5) || (pattern->policy == 3))
			{
				break;
			}
			if (system_state == 5)
			{
				if ((pattern->policy == 4) || (!display_state && pattern->policy == 2))
				{
					break;
				}
			}
			else
			{
				if ( !display_state || pattern->policy == 1 )
				{
					break;
				}
			}
		}
		if ( (!vibrator_enabled && pattern->policy != 5) || call_state == 2 )
		{
			current = 0;
			pattern->active = 0;
			stop_vibrator();
			cancel_vibrator_timeout();
			return;
		}
		if ( pattern != current )
		{
			stop_vibrator();
			cancel_vibrator_timeout();
			if (pattern->timeout != -1)
			{
				vibrator_timeout_cb_id = g_timeout_add_seconds(pattern->timeout,vibrator_timeout_cb, 0);				
			}
			current = pattern;
			vibrator_state = 0;
			update_vibrator_state();
		}
	}
}

void call_state_pipe_handler(gconstpointer data)
{
	(void)data;
	start_vibrator();
}

void display_state_pipe_handler(gconstpointer data)
{
	(void)data;
	start_vibrator();
}

void system_state_pipe_handler(gconstpointer data)
{
	(void)data;
	start_vibrator();
}

void vibrator_enable(void)
{
	start_vibrator();
	vibrator_enabled = 1;
	
}

gboolean vibrator_timeout_cb(gpointer data)
{
	(void)data;
	current->active = 0;
	start_vibrator();
	return 0;
}

gboolean vibrator_on_off_timeout_cb(gpointer data)
{
	(void)data;
	update_vibrator_state();
	return 0;
}

const gchar *g_module_check_init(GModule *module)
{
	(void)module;
	gchar **patterns;
	gchar *pattern;
	int count = 0;
	gint *patterndata;
	guint length;
	vibrator_pattern_struct *patternstr;
	remove_output_trigger_from_datapipe(&vibrator_pattern_deactivate_pipe, vibrator_pattern_deactivate_pipe_handler);
	remove_output_trigger_from_datapipe(&vibrator_pattern_activate_pipe, vibrator_pattern_activate_pipe_handler);
	append_output_trigger_to_datapipe(&system_state_pipe, system_state_pipe_handler);
	append_output_trigger_to_datapipe(&display_state_pipe, display_state_pipe_handler);
	append_output_trigger_to_datapipe(&call_state_pipe, call_state_pipe_handler);
	vibrator_patterns = g_queue_new();
	if ( get_vibrator_type() != 1 )
	{
		return 0;
	}
	patterns = mce_conf_get_string_list("Vibrator", "VibratorPatterns", &length, 0);
	if ( !patterns )
	{
		mce_log(3, "Failed to configure vibrator patterns");
		return 0;
	}
	while ((pattern = patterns[count]) != 0)
	{
		mce_log(5, "Getting Vibra pattern for: %s", pattern);
		patterndata = mce_conf_get_int_list(vibrator_patterns_name, pattern, &length, 0);
		if ( !patterndata )
		{
			count++;
			continue;
		}
		if ( length != 9 )
		{
			mce_log(2, "Skipping invalid Vibra-pattern");
			g_free(patterndata);
			count++;
			continue;
		}
		patternstr = (vibrator_pattern_struct *)g_slice_alloc(0x2Cu);
		if ( patternstr )
		{
			patternstr->name = g_strdup(pattern);
			patternstr->priority = patterndata[0];
			patternstr->policy = patterndata[1];
			patternstr->timeout = patterndata[2];
			if (!patternstr->timeout)
			{
				patternstr->timeout = -1;
			}
			patternstr->repeat = abs(patterndata[3]);
			patternstr->accelerate_period = abs(patterndata[4]);
			patternstr->on_period = abs(patterndata[5]);
			patternstr->break_period = abs(patterndata[6]);
			patternstr->off_period = abs(patterndata[7]);
			patternstr->speed = abs(patterndata[8]);
			patternstr->active = 0;
			g_queue_insert_sorted(vibrator_patterns, patternstr, vibrator_pattern_sort_func, 0);
		}
		g_free(patterndata);
		count++;
	}
	g_strfreev(patterns);
	if ( mce_dbus_handler_add("com.nokia.mce.request","req_vibrator_pattern_activate",0,1,req_vibrator_pattern_activate_cb) )
	{
		if ( mce_dbus_handler_add("com.nokia.mce.request","req_vibrator_pattern_deactivate",0,1,req_vibrator_pattern_deactivate_cb) )
		{
			if ( mce_dbus_handler_add("com.nokia.mce.request", "req_vibrator_enable", 0, 1u, req_vibrator_enable_cb) )
			{
				if ( mce_dbus_handler_add("com.nokia.mce.request", "req_vibrator_disable", 0, 1u, req_vibrator_disable_cb) )
				{
					if ( mce_dbus_handler_add("com.nokia.mce.request","req_start_manual_vibration",0,1,req_start_manual_vibration_cb) )
					{
						if ( mce_dbus_handler_add("com.nokia.mce.request","req_stop_manual_vibration",0,1,req_stop_manual_vibration_cb) )
						{
							vibrator_enable();
						}
					}
				}
			}
		}
	}
	return 0;
}

gboolean req_vibrator_disable_cb(DBusMessage *const msg)
{
	mce_log(5, "Received vibrator disable request");
	vibrator_disable();
	if (dbus_message_get_no_reply(msg))
	{
		return TRUE;
	}
	else
	{
		return dbus_send_message(dbus_new_method_reply(msg));
	}
	return 0;
}

gboolean req_vibrator_enable_cb(DBusMessage *const msg)
{
	mce_log(5, "Received vibrator enable request");
	vibrator_enable();
	if (dbus_message_get_no_reply(msg))
	{
		return TRUE;
	}
	else
	{
		return dbus_send_message(dbus_new_method_reply(msg));
	}
	return 0;
}

void deactivate_vibrator_pattern(const gchar *pattern)
{
	if (pattern)
	{
		GList *item = g_queue_find_custom(vibrator_patterns, pattern, vibrator_search_cb);
		if (item)
		{
			((vibrator_pattern_struct *)item->data)->active = 0;
			start_vibrator();
			mce_log(5, "Vibrator pattern %s deactivated",pattern);
			return;
		}
	}
	mce_log(5, "Received request to deactivate a non-existing vibrator pattern");
}

void vibrator_pattern_deactivate_pipe_handler(gconstpointer data)
{
	deactivate_vibrator_pattern(data);
}

gboolean req_stop_manual_vibration_cb(DBusMessage *const msg)
{
	mce_log(5, "Received stop manual vibration request");
	GList *item = g_queue_find_custom(vibrator_patterns, "PatternUserManual", vibrator_search_cb);
	if (item)
	{
		((vibrator_pattern_struct *)item->data)->speed = 0;
		((vibrator_pattern_struct *)item->data)->on_period = 0;
		deactivate_vibrator_pattern("PatternUserManual");
	}
	else
	{
		mce_log(2, "USER_MANUAL_PATTERN_NAME is a non-existing vibrator pattern");
	}
	if (dbus_message_get_no_reply(msg))
	{
		return TRUE;
	}
	else
	{
		return dbus_send_message(dbus_new_method_reply(msg));
	}
	return 0;
}

void activate_vibrator_pattern(const gchar *pattern)
{
	if (pattern)
	{
		GList *item = g_queue_find_custom(vibrator_patterns, pattern, vibrator_search_cb);
		if (item)
		{
			call_state_t call_state = datapipe_get_gint(call_state_pipe);
			if (call_state == CALL_STATE_ACTIVE)
			{
				mce_log(5, "Ignored request to activate vibra pattern during active call");
			}
			else
			{
				((vibrator_pattern_struct *)item->data)->active = 1;
				start_vibrator();
				mce_log(5, "Vibrator pattern %s activated", pattern);
			}
			return;
		}
	}
	mce_log(5, "Received request to activate a non-existing vibrator pattern");
}

void vibrator_pattern_activate_pipe_handler(gconstpointer data)
{
	activate_vibrator_pattern(data);
}

gint vibrator_search_cb(gconstpointer a, gconstpointer b)
{
	vibrator_pattern_struct *str = (vibrator_pattern_struct *)a;
	gchar *pattern = (gchar *)b;
	if ( str && pattern && str->name )
	{
		return strcmp(str->name,pattern);
	}
	return -1;
}

gboolean req_start_manual_vibration_cb(DBusMessage *const msg)
{
	gint speed = 0;
	gint duration = 0;
	DBusError error;
	dbus_error_init(&error);
	mce_log(5, "Received start manual vibration request");
	if ( dbus_message_get_args(msg, &error, 'i', &speed, 'i', &duration, 0) )
	{
		mce_log(5, "Manual pattern details: speed = %d, duration = %d ms",speed,duration);
		GList *item = g_queue_find_custom(vibrator_patterns, "PatternUserManual", vibrator_search_cb);
		if (item)
		{
			if (((vibrator_pattern_struct *)item->data)->active)
			{
				deactivate_vibrator_pattern("PatternUserManual");
			}
			if ((speed + 255) > 510)
			{
				mce_log(3, "Wrong speed requested (%d)",speed);
			}
			else
			{
				((vibrator_pattern_struct *)item->data)->speed = speed;
				((vibrator_pattern_struct *)item->data)->on_period = duration;
				activate_vibrator_pattern("PatternUserManual");
			}
		}		
		else
		{
			mce_log(2, "USER_MANUAL_PATTERN_NAME is a non-existing vibrator pattern");
		}
		if (dbus_message_get_no_reply(msg))
		{
			return TRUE;
		}
		else
		{
			return dbus_send_message(dbus_new_method_reply(msg));
		}
	}
	else
	{
		mce_log(1,"Failed to get argument from %s.%s: %s","com.nokia.mce.request","req_vibrator_pattern_activate",error.message);
		dbus_error_free(&error);
		return 0;
	}
	return 0;
}

gboolean req_vibrator_pattern_deactivate_cb(DBusMessage *const msg)
{
	char *pattern = 0;
	DBusError error;
	dbus_error_init(&error);
	mce_log(5, "Received deactivate vibrator pattern request");
	if ( dbus_message_get_args(msg, &error, 's', &pattern, 0) )
	{
		deactivate_vibrator_pattern(pattern);
		if (dbus_message_get_no_reply(msg))
		{
			return TRUE;
		}
		else
		{
			return dbus_send_message(dbus_new_method_reply(msg));
		}
	}
	else
	{
		mce_log(1,"Failed to get argument from %s.%s: %s","com.nokia.mce.request","req_vibrator_pattern_deactivate",error.message);
		dbus_error_free(&error);
		return 0;
	}
	return 0;
}

gboolean req_vibrator_pattern_activate_cb(DBusMessage *const msg)
{
	char *pattern = 0;
	DBusError error;
	dbus_error_init(&error);
	mce_log(5, "Received activate vibrator pattern request");
	if ( dbus_message_get_args(msg, &error, 's', &pattern, 0) )
	{
		activate_vibrator_pattern(pattern);
		if (dbus_message_get_no_reply(msg))
		{
			return TRUE;
		}
		else
		{
			return dbus_send_message(dbus_new_method_reply(msg));
		}
	}
	else
	{
		mce_log(1,"Failed to get argument from %s.%s: %s","com.nokia.mce.request","req_vibrator_pattern_activate",error.message);
		dbus_error_free(&error);
		return 0;
	}
	return 0;
}

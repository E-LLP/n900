#ifndef _ALCHEMY_GPIO_H_
#define _ALCHEMY_GPIO_H_

#if defined(CONFIG_ALCHEMY_GPIOINT_AU1000)

#include <asm/mach-au1x00/gpio-au1000.h>

#endif

#endif	/* _ALCHEMY_GPIO_H_ */

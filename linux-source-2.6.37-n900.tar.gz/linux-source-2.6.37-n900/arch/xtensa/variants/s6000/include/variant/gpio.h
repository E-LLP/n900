#ifndef _XTENSA_VARIANT_S6000_GPIO_H
#define _XTENSA_VARIANT_S6000_GPIO_H

extern int s6_gpio_init(u32 afsel);

#endif /* _XTENSA_VARIANT_S6000_GPIO_H */

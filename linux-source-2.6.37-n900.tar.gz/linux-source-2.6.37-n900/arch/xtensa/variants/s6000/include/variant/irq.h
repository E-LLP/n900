#ifndef _XTENSA_S6000_IRQ_H
#define _XTENSA_S6000_IRQ_H

#define NO_IRQ		(-1)
#define VARIANT_NR_IRQS 8 /* GPIO interrupts */

extern void variant_irq_enable(unsigned int irq);

#endif /* __XTENSA_S6000_IRQ_H */
